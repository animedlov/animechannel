export interface EpisodeInfo {
  number: number;
  url: string;
}