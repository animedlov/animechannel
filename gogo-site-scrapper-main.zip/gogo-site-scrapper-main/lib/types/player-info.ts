export interface PlayerInfo {
  name: string,
  url: string
}