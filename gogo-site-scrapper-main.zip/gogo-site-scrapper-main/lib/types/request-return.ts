export interface RequestReturn {
  document: HTMLDocument,
  url: string
}